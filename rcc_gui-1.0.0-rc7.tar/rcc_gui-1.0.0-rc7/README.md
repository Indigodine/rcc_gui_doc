# RCC GUI

Graphical User Interface for the RCC.

## Table of content

[[_TOC_]]

## Project structure

The table below provides a brief description for all top level files.

| file             | description |
|------------------|-------------|
| `.images/`       | Contains `Dockerfile`s used by GitLab CI/CD jobs. |
| `bin/`           | Contains scripts bundled with generated Debian packages. |
| `deb/`           | Contains resources related to the generation of Debian packages. |
| `lib/`           | Contains jar files required to build and run the application. |
| `src/`           | Contains the source code of the project. |
| `.gitignore`     | Rules to track files (or not) with `git`. |
| `.gitlab-ci.yml` | Job definitions for GitLab CI/CD. |
| `README.md`      | The file you are currently reading. |
| `build.xml`      | Ant build definitions file. |

## Build dependencies

To build the project, the following dependencies are required.

- Apache [Ant](https://ant.apache.org/)

  ```
  sudo apt install ant
  ```

- Java Development Kit 8

  ```
  sudo apt install openjdk-8-jdk
  ```

## Build instructions

The project uses `ant` as build system. To build the jar file, execute the
command below (in the project folder).

```
ant jar -Dproject.version=<version>
```

> If several Java versions are installed, make sure that Java 8 is used `java
> -version`. The project can only be built and run with Java 8. On Debian
> systems `update-java-alternatives` can be used to change the default java
> version (see below).
>
> ```
> update-java-alternatives --list
> sudo update-java-alternatives --set /usr/lib/jvm/java-1.8.0-openjdk-amd64
> ```

Once `dist/out.jar` is built, the application can be executed with `java -jar
dist/out.jar`.

## Installation

### Ubuntu

#### Download the .jar file

The application `.jar` file can be downloaded on the release
[page](https://gitlab.in2p3.fr/Ganil-acq/RunControl/rcc_gui/-/releases).

#### Download the .deb file

The Debian package can be downloaded on the release
[page](https://gitlab.in2p3.fr/Ganil-acq/RunControl/rcc_gui/-/releases).

#### Install with apt

The application can be installed with `apt` on computers configured to fetch
packages from the Debian repository managed by the "Groupe des Techniques
d'Acquisition". The following command shows how to install version 1.0.0.

```
sudo apt install ganilrccgui1.0.0
```

## Usage

Once installed, the application can be started by calling `ganilrccgui1.0.0`
(change the version number to match one of the versions installed on the
computer).

```
ganilrccgui1.0.0
```

The application requires the following variables to be set in order to run
properly.

| Variables             | Descriptions |
|-----------------------|--------------|
| `RCC_SAVE_PATH`       | A path where things are saved. |
| `RCC_EXPERIMENT_NAME` | A name that identifies the experiment. |
| `RCC_HOST`            | The network hostname or ip address of the host running the RCC service. |
| `RCC_PORT`            | The port on which the RCC service is running. |

```
export RCC_SAVE_PATH=".rcc"
export RCC_EXPERIMENT_NAME="MyExp"
export RCC_PORT="8061"
export RCC_HOST="127.0.0.1"
ganilrccgui1.0.0
```

> If several Java versions are installed, make sure that Java 8 is used `java
> -version`. The project can only be built and run with Java 8. On Debian
> systems `update-java-alternatives` can be used to change the default java
> version (see below).
>
> ```
> update-java-alternatives --list
> sudo update-java-alternatives --set /usr/lib/jvm/java-1.8.0-openjdk-amd64
> ```

## Project Members

Thomas Charpentier <thomas.charpentier@ganil.fr>
