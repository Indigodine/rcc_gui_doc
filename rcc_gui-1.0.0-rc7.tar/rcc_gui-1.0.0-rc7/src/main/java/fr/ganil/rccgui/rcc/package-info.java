@javax.xml.bind.annotation.XmlSchema(namespace = "urn:rcc", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package fr.ganil.rccgui.rcc;
