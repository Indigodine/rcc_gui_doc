package fr.ganil.rccgui;

import fr.ganil.rccgui.gui.containers.Window;

public class Main {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Window();
	}

}
